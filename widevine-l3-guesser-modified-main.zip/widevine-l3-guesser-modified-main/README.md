## Screens

![image](https://user-images.githubusercontent.com/20772925/127744128-4a91d09b-a4f0-44b2-9e7b-2a9667d94cbe.png)

# Made by nilaoda <https://github.com/nilaoda/widevine-l3-guesser/tree/modified>

I just removed base64 key entries and added download as **keys.json** file.

### You can use this extension with my script : <https://github.com/parnexcodes/widevine-L3-WEB-DL-Script>
